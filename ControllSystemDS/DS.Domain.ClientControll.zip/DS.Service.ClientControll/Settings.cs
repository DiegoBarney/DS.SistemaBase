﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS.Service.ClientControll
{
    public class Settings
    {
        public static string secret = "fedaf7d8863b48e197b9287d492b708e";
    }
}
